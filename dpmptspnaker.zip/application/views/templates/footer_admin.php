<script src="<?= base_url(); ?>assets/jquery-3.4.1.min.js"></script>
<script src="<?= base_url(); ?>assets/popper.js"></script>
<script src="<?= base_url(); ?>assets/js/bootstrap.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>
    feather.replace()
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#dataTables-example').DataTable();
    });
</script>
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>
    feather.replace()
</script>
<script src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>
<script type="text/javascript">
    $(function() {
        CKEDITOR.replace('ckeditor');
        CKEDITOR.replace('ckeditor2');
    });
</script>
</body>

</html>