<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
	<div class="container-fluid wallpaper-admin" style="background-image: url('<?= base_url(); ?>assets/img/wallpaper.jpg');
	background-attachment: fixed;
  	background-repeat: no-repeat;
  	background-size: cover;
  	height:85%;">
		<div class="text-center text-white">
			<h1 class="welcome display-4">SELAMAT DATANG</h1>
			<img src="<?= base_url(); ?>assets/img/agam.png" width="200px" alt="Logo e-Naker" style="margin:20px; width:100px;">
			<h4 class="display-4 judul-admin">DINAS PENANAMAN MODAL PELAYANAN TERPADU SATU PINTU DAN KETENAGAKERJAAN<br />KABUPATEN AGAM</h4>
		</div>
	</div>
</main>